import AboutUs from '@/components/AboutUs'
import React from 'react'

function page() {
  return (
    <div>
      <AboutUs/>
    </div>
  )
}

export default page
