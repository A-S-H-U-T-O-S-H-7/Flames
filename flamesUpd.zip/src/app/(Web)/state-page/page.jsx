import StatePage from '@/components/StatePage'
import React from 'react'

function page() {
  return (
    <div>
      <StatePage/>
    </div>
  )
}

export default page
