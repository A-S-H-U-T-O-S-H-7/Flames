import FeaturedCollectionPage from '@/components/FeaturedCollectionPage'
import React from 'react'

function page() {
  return (
    <div>
      <FeaturedCollectionPage/>
    </div>
  )
}

export default page
