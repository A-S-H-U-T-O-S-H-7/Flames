import React from 'react'

function page() {
  return (
    <div>
      <h1>hi</h1>
    </div>
  )
}

export default page
