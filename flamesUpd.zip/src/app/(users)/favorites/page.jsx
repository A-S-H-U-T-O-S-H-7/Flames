import React from 'react'
import Favorites from '@/components/Favorites'

function page() {
  return (
    <div>
      <Favorites/>
    </div>
  )
}

export default page
