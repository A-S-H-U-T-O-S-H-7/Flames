import Cart from '@/components/Cart'
import React from 'react'

function page() {
  return (
    <div>
      <Cart/>

    </div>
  )
}

export default page
