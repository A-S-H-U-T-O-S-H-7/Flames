import React from 'react'

function OrdersChart() {
  return (
    <div>
      
    </div>
  )
}

export default OrdersChart
