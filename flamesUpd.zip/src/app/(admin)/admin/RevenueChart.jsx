import React from 'react'

function RevenueChart() {
  return (
    <div>
      
    </div>
  )
}

export default RevenueChart
