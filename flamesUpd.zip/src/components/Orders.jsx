"use client";
import { useEffect, useState } from "react";
import { useAuth } from "@/context/AuthContext";
import { db } from "@/lib/firestore/firebase";
import { collection, getDocs, query, where, updateDoc, doc } from "firebase/firestore";
import { CircularProgress } from "@nextui-org/react";
import Link from "next/link";
import { FaWhatsapp } from "react-icons/fa";

// Order Item Component
const OrderItem = ({ item }) => (
  <div className="flex bg-gray-50 rounded-lg p-3 w-full sm:w-auto sm:max-w-xs">
    <div className="w-16 h-16 rounded-lg overflow-hidden flex-shrink-0">
      <img
        src={item.product_data.images[0]}
        alt={item.product_data.name}
        className="w-full h-full object-cover"
      />
    </div>
    <div className="ml-3 flex-grow">
      <Link href={`/products/${item.product_id}`} className="text-sm font-semibold text-blue-600 hover:underline">
        {item.product_data.name}
      </Link>
      <p className="text-xs text-gray-600 mt-1">
        {item.product_data.description || "No description available"}
      </p>
      <p className="text-xs font-medium mt-1 text-gray-600">
        Quantity - {item.quantity}
      </p>
    </div>
  </div>
);

// Order Details Component
const OrderDetails = ({ order }) => (
  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
    <div>
      <h3 className="text-xs font-semibold text-gray-700">Order ID</h3>
      <p className="mt-1 text-sm font-medium text-gray-900">{order.id}</p>
    </div>
    <div className="col-span-2 md:col-span-1">
      <h3 className="text-xs font-semibold text-gray-700">Delivery Address</h3>
      <p className="mt-1 text-sm text-gray-900">{order.address.fullName}</p>
      <p className="text-xs text-gray-600">{order.address.addressLine1}</p>
      <p className="text-xs text-gray-600">
        {order.address.city}, {order.address.pincode}
      </p>
      <p className="text-xs text-gray-600">
        Mobile: {order.address.mobile || "N/A"}
      </p>
    </div>
    <div>
      <h3 className="text-xs font-semibold text-gray-700">
        {order.status.toLowerCase() === "delivered" ? "Paid Amount" : "Amount to be Paid"}
      </h3>
      <p className="mt-1 text-sm font-medium text-gray-900">
        ₹{order.total} <span className="text-xs text-gray-600">({order.paymentMode})</span>
      </p>
    </div>
  </div>
);

// Order Status Component
const OrderStatus = ({ status }) => {
  const statuses = ["pending", "shipped", "transit", "delivered"];
  const statusIndex = statuses.indexOf(status.toLowerCase());
  
  const getStatusColor = (status) => {
    switch (status.toLowerCase()) {
      case "pending": return "bg-yellow-100 text-yellow-800";
      case "shipped": return "bg-blue-100 text-blue-800";
      case "transit": return "bg-purple-100 text-purple-800";
      case "delivered": return "bg-green-100 text-green-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div>
      <h3 className="text-xs font-semibold text-gray-700 mb-2">Order Status</h3>
      <div className="mb-4">
        <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(status)}`}>
          {status.charAt(0).toUpperCase() + status.slice(1)}
        </span>
      </div>
      <div className="relative mb-6">
        {/* Milestone labels above progress bar */}
        <div className="flex justify-between text-xs text-gray-600 mb-1">
          {statuses.map((s, i) => (
            <div key={i} className="capitalize">{s}</div>
          ))}
        </div>
        
        {/* Progress bar with milestones */}
        <div className="relative h-2 bg-gray-200 rounded">
          <div 
            className="absolute top-0 left-0 h-2 bg-blue-500 rounded" 
            style={{ width: `${(statusIndex + 1) * 25}%` }}
          ></div>
          
          {/* Milestone dots */}
          {statuses.map((s, i) => (
            <div 
              key={i} 
              className={`absolute top-1/2 transform -translate-y-1/2 w-4 h-4 rounded-full ${statusIndex >= i ? "bg-blue-500" : "bg-gray-300"}`}
              style={{ left: `calc(${i * 25}% - ${i > 0 ? "8px" : "0px"})`, zIndex: 10 }}
            ></div>
          ))}
        </div>
      </div>
    </div>
  );
};

// Empty Orders Component
const EmptyOrders = () => (
  <div className="bg-white rounded-lg shadow-md p-6 text-center">
    <p className="text-gray-600">You don't have any orders yet.</p>
    <Link href="/products" className="mt-4 inline-block px-4 py-2 text-sm bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-md transition-all">
      Start Shopping
    </Link>
  </div>
);

// WhatsApp Support Component
const WhatsAppSupport = () => (
  <a 
    href="https://wa.me/yourphonenumber" 
    target="_blank" 
    rel="noopener noreferrer"
    className="fixed bottom-4 right-4 bg-green-500 text-white p-3 rounded-full shadow-lg hover:bg-green-600 transition-all flex items-center gap-2"
  >
    <FaWhatsapp size={20} />
    <span className="hidden md:inline">Message us for help</span>
  </a>
);

// Main Orders Component
export default function Orders() {
  const { user } = useAuth();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [cancelModalOpen, setCancelModalOpen] = useState(false);
  const [selectedOrderId, setSelectedOrderId] = useState(null);

  useEffect(() => {
    if (!user) return;
    const fetchOrders = async () => {
      try {
        const q = query(collection(db, "orders"), where("uid", "==", user.uid));
        const querySnapshot = await getDocs(q);
        const ordersData = querySnapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
        setOrders(ordersData);
      } catch (error) {
        console.error("Error fetching orders:", error);
      }
      setLoading(false);
    };
    fetchOrders();
  }, [user]);

  const handleCancelOrder = async (orderId) => {
    if (!confirm("Are you sure you want to cancel this order?")) {
      return;
    }
    
    try {
      const orderRef = doc(db, "orders", orderId);
      await updateDoc(orderRef, {
        status: "cancelled",
        cancelledAt: new Date()
      });
      
      // Update the orders state
      setOrders(orders.map(order => 
        order.id === orderId 
          ? { ...order, status: "cancelled", cancelledAt: new Date() } 
          : order
      ));
      
      alert("Order cancelled successfully");
    } catch (error) {
      console.error("Error cancelling order:", error);
      alert("Failed to cancel order. Please try again.");
    }
  };

  if (loading) return <div className="flex justify-center mt-10"><CircularProgress /></div>;

  return (
    <div className="p-4 md:p-6 bg-gray-100 min-h-screen">
      {orders.length > 0 ? (
        <div className="space-y-5">
          {orders.map((order) => (
            <div key={order.id} className="bg-white rounded-lg shadow-md overflow-hidden p-4">
              {/* Products Section */}
              <div className="border-b border-gray-200 pb-3 mb-3">
                <div className="flex flex-wrap gap-4">
                  {order.line_items.map((item, index) => (
                    <OrderItem key={index} item={item} />
                  ))}
                </div>
              </div>
              
              {/* Order Details Section */}
              <div className="border-b border-gray-200 pb-3 mb-3">
                <OrderDetails order={order} />
              </div>
              
              {/* Status Section */}
              <OrderStatus status={order.status} />
              
              {/* Action Buttons */}
              <div className="mt-4 flex flex-wrap gap-2 justify-between items-center">
                {/* Rate Button (if delivered) */}
                {order.status.toLowerCase() === "delivered" && (
                  <Link 
                    href={`/products/${order.line_items[0].product_id}?rate=true`}
                    className="inline-flex items-center justify-center px-4 py-2 text-sm bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-md transition-all"
                  >
                    Rate this Purchase
                  </Link>
                )}
                
                {/* Cancel Button (if pending) */}
                {order.status.toLowerCase() === "pending" && (
                  <button 
                    onClick={() => handleCancelOrder(order.id)}
                    className="px-4 py-2 text-sm bg-red-600 hover:bg-red-700 text-white font-medium rounded-md transition-all"
                  >
                    Cancel Order
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <EmptyOrders />
      )}
      
      <WhatsAppSupport />
    </div>
  );
}