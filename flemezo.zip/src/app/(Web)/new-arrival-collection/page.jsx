import React from 'react'
import NewArrivalCollectionPage from '@/components/NewArrivalCollectionPage'

function page() {
  return (
    <div>
      <NewArrivalCollectionPage/>
    </div>
  )
}

export default page
