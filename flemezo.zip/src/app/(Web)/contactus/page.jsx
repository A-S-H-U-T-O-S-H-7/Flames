import ContactUs from '@/components/ContactUs'
import React from 'react'

function page() {
  return (
    <div>
      <ContactUs/>
    </div>
  )
}

export default page
